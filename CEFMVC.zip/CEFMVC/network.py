import torch.nn.init as init
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Parameter
from torch.nn.init import xavier_normal_

class FeatureContrastiveModule(nn.Module):
    def __init__(self, feature_dim, high_feature_dim, device):
        super(FeatureContrastiveModule, self).__init__()
        # 定义一个线性层，将 feature_dim 映射到 high_feature_dim
        self.fc =  nn.Sequential(
            nn.Linear(feature_dim, 1024),
            nn.ReLU(),
            nn.Linear(1024, feature_dim),
        )

    def forward(self, z):
        # 通过线性层转换特征，并进行归一化处理
        h = self.fc(z)
        return F.normalize(h, p=2, dim=1)  # 使用L2范数进行归一化


class Network_FL(nn.Module):
    def __init__(self, batch_size, input_size, feature_dim, high_feature_dim, class_num, device):
        super(Network_FL, self).__init__()
        self.batch_size = batch_size
        self.temperature_f = 0.5
        self.cos_sim = nn.CosineSimilarity(dim=-1)
        self.criterion = nn.CrossEntropyLoss(reduction="sum")
        self.encoder = nn.Sequential(
            nn.Linear(input_size, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),
            nn.ReLU(),
            nn.Linear(2000, feature_dim),
        )

        self.decoder = nn.Sequential(
            nn.Linear(feature_dim, 2000),
            nn.ReLU(),
            nn.Linear(2000, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, input_size)
        )

        self.feature_contrastive_module = FeatureContrastiveModule(feature_dim, high_feature_dim, device)


        self.centroids = Parameter(torch.Tensor(class_num, feature_dim))


        init.xavier_normal_(self.centroids)

    def forward(self, x):
        z = self.encoder(x)
        h = self.feature_contrastive_module(z)
        xr = self.decoder(z)
        q = 1.0 / (1.0 + torch.sum(torch.pow(z.unsqueeze(1) - self.centroids, 2), 2))
        q = (q.t() / torch.sum(q, 1)).t()
        return h, q, xr, z


