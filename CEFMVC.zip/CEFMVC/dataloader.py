from sklearn.preprocessing import MinMaxScaler
import numpy as np
from torch.utils.data import Dataset
import scipy.io
import torch
import scipy.io as scio
from sklearn import preprocessing

min_max_scaler = preprocessing.MinMaxScaler()


class DatasetSplit(Dataset):

    def __init__(self, dataset_x, dataset_y, dim, probabilities):
        self.dataset_x = dataset_x
        self.dataset_y = dataset_y
        self.dim = dim
        self.probabilities = probabilities  # 初始化概率矩阵为None

    def __len__(self):
        return len(self.dataset_y)

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __getitem__(self, item):
        image, label = self.dataset_x[item], self.dataset_y[item]
        image = image.reshape(self.dim)
        if self.probabilities is not None:
            probability_matrix = self.probabilities[item]
        else:
            probability_matrix = torch.zeros_like(torch.Tensor([item]), dtype=torch.float32)
        return torch.tensor(image), torch.tensor(label), probability_matrix


class BDGP(Dataset):
    def __init__(self, path):
        self.X1 = scipy.io.loadmat(path + 'BDGP.mat')['X1'].astype(np.float32)
        self.X2 = scipy.io.loadmat(path + 'BDGP.mat')['X2'].astype(np.float32)
        self.labels = scipy.io.loadmat(path + 'BDGP.mat')['Y'].transpose()

        self.probabilities = None  # 初始化概率矩阵为None

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.X1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)

        return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx])], torch.from_numpy(self.labels[idx]), probability_matrix


class BBCSport(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path + 'bbcsport.mat')
        data1 = data['X1'].astype(np.float32).T
        data2 = data['X2'].astype(np.float32).T
        labels = data['truth'].reshape(544, ) - 1
        self.X1 = data1
        self.X2 = data2
        self.labels = labels
        self.probabilities = None  # 初始化概率矩阵为None

    def __len__(self):
        return len(self.X1[0])

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)

        return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx])], torch.from_numpy(self.labels[idx]), probability_matrix


class REU(Dataset):
    def __init__(self, path):
        data = scio.loadmat(path + "REU.mat")
        self.x1 = data['X1'].astype(np.float32)
        self.x2 = data['X2'].astype(np.float32)
        self.x3 = data['X3'].astype(np.float32)
        self.x4 = data['X4'].astype(np.float32)
        self.x5 = data['X5'].astype(np.float32)
        self.labels = np.copy(data['Y'][0]).astype(np.int32).reshape(1200, ) - 1

        self.probabilities = None  # 初始化概率矩阵为None
        from sklearn import preprocessing
        min_max_scaler = preprocessing.MinMaxScaler()
        self.X1 = min_max_scaler.fit_transform(self.x1)
        self.X2 = min_max_scaler.fit_transform(self.x2)
        self.X3 = min_max_scaler.fit_transform(self.x3)
        self.X4 = min_max_scaler.fit_transform(self.x4)
        self.X5 = min_max_scaler.fit_transform(self.x5)


    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.x1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)

        return [self.x1[idx], self.x2[idx], self.x3[idx], self.x4[idx], self.x5[idx]], self.Y[idx], probability_matrix


class COIL20(Dataset):
    def __init__(self, path):
        data = scio.loadmat(path + "COIL20.mat")
        self.x1 = data['X'][0][0].astype(np.float32)
        self.x2 = data['X'][0][1].astype(np.float32)
        self.x3 = data['X'][0][2].astype(np.float32)
        self.Y = np.copy(data['Y']).astype(np.int32).reshape(1440, )
        self.probabilities = None  # 初始化概率矩阵为None

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.x1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.x1[idx]), torch.from_numpy(self.x2[idx]), torch.from_numpy(self.x3[idx])], \
            self.Y[idx], probability_matrix


class synthetic3d(Dataset):
    def __init__(self, path):
        data = scio.loadmat(path + "synthetic3d.mat")
        self.X1 = data['X'][0][0].astype(np.float32)
        self.X2 = data['X'][1][0].astype(np.float32)
        self.X3 = data['X'][2][0].astype(np.float32)
        self.labels = np.copy(data['Y']).astype(np.int32).reshape(600, )
        self.probabilities = None  # 初始化概率矩阵为None

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.X1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx]), torch.from_numpy(self.X3[idx])], \
            self.Y[idx], probability_matrix


class scene(Dataset):
    def __init__(self, path):
        data = scio.loadmat(path + "scene-15.mat")
        self.X1 = data['X'][0][0].astype(np.float32)
        self.X2 = data['X'][0][1].astype(np.float32)
        self.X3 = data['X'][0][2].astype(np.float32)
        self.labels = np.copy(data['Y']).astype(np.int32).reshape(4485, )
        self.probabilities = None  # 初始化概率矩阵为None

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.X1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx]), torch.from_numpy(self.X3[idx])], \
            self.labels[idx], probability_matrix


class LandUse_21(Dataset):
    def __init__(self, path):
        data = scio.loadmat(path + "LandUse_21.mat")
        self.x1 = data['X'][0][0].astype(np.float32)
        self.x2 = data['X'][0][1].astype(np.float32)
        self.x3 = data['X'][0][2].astype(np.float32)
        min_max_scaler = preprocessing.MinMaxScaler()
        self.X1 = min_max_scaler.fit_transform(self.x1)
        self.X2 = min_max_scaler.fit_transform(self.x2)
        self.X3 = min_max_scaler.fit_transform(self.x3)
        self.labels = np.copy(data['Y']).astype(np.int32).reshape(2100, )
        self.probabilities = None  # 初始化概率矩阵为None

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.X1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx]), torch.from_numpy(self.X3[idx])], \
            self.labels[idx], probability_matrix


class LLMs(Dataset):
    def __init__(self, path):
        data = scio.loadmat(path + "LLM32.mat")
        self.view1 = data['V1'].astype(np.float32).astype(np.float32)
        self.view2 = data['V2'].astype(np.float32).astype(np.float32)
        self.view3 = data['V3'].astype(np.float32).astype(np.float32)
        self.labels = np.copy(data['Y']).astype(np.int32).reshape(1000, )
        self.probabilities = None  # 初始化概率矩阵为None
        from sklearn import preprocessing
        min_max_scaler = preprocessing.MinMaxScaler()
        self.X1 = min_max_scaler.fit_transform(self.view1)
        self.X2 = min_max_scaler.fit_transform(self.view2)
        self.X3 = min_max_scaler.fit_transform(self.view3)

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.X1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx]), torch.from_numpy(self.X3[idx])], \
            self.labels[idx], probability_matrix


class NUSWIDE(Dataset):
    def __init__(self, path):
        data = scio.loadmat(path + "NUSWIDE.mat")
        self.X1 = data['X1'].astype(np.float32)
        self.X2 = data['X2'].astype(np.float32)
        self.X3 = data['X3'].astype(np.float32)
        self.X4 = data['X4'].astype(np.float32)
        self.X5 = data['X5'].astype(np.float32)
        self.labels = np.copy(data['Y']).astype(np.int32).reshape(5000, )
        rep_mapping = {14: 0, 19: 1, 23: 2, 28: 3, 29: 4}
        for i in range(len(self.labels)):
            idy = rep_mapping.get(self.labels[i])
            self.labels[i] = idy
        self.probabilities = None  # 初始化概率矩阵为None
        indices = np.random.permutation(len(self.X1))
        self.X1 = self.X1[indices]
        self.X2 = self.X2[indices]
        self.X3 = self.X3[indices]
        self.X4 = self.X4[indices]
        self.X5 = self.X5[indices]
        self.labels = self.labels[indices]

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.X1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx]), torch.from_numpy(self.X3[idx]), torch.from_numpy(self.X4[idx]), torch.from_numpy(self.X5[idx])], self.labels[idx], probability_matrix


class YoutubeFace_sel_fea(Dataset):
    def __init__(self, path):
        data = scio.loadmat(path + "YoutubeFace_sel_fea.mat")
        self.x1 = data['X'][0][0].astype(np.float32)
        self.x2 = data['X'][1][0].astype(np.float32)
        self.x3 = data['X'][2][0].astype(np.float32)
        self.x4 = data['X'][3][0].astype(np.float32)
        self.x5 = data['X'][4][0].astype(np.float32)
        self.Y = np.copy(data['Y']).astype(np.int32).reshape(101499, )
        self.probabilities = None  # 初始化概率矩阵为None

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.x1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.x1[idx]), torch.from_numpy(self.x2[idx]), torch.from_numpy(self.x3[idx]), torch.from_numpy(self.x4[idx]), torch.from_numpy(self.x5[idx])], \
            self.Y[idx], probability_matrix


class Caltech101(Dataset):
    def __init__(self, path):
        data = scio.loadmat(path + "Caltech101.mat")
        self.x1 = data['fea'][0][0].astype(np.float32)
        self.x2 = data['fea'][0][1].astype(np.float32)
        self.x3 = data['fea'][0][2].astype(np.float32)
        self.x4 = data['fea'][0][3].astype(np.float32)
        self.x5 = data['fea'][0][4].astype(np.float32)
        self.x6 = data['fea'][0][5].astype(np.float32)
        self.Y = np.copy(data['gt']).astype(np.int32).reshape(9144, )
        self.probabilities = None  # 初始化概率矩阵为None

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.x1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.x1[idx]), torch.from_numpy(self.x2[idx]), torch.from_numpy(self.x3[idx]), torch.from_numpy(self.x4[idx]), torch.from_numpy(self.x5[idx])], self.Y[idx], probability_matrix


class STL10(Dataset):
    def __init__(self, path):
        import h5py
        with h5py.File(path, 'r') as data:
            # Extract the actual dataset for each view from the reference in X
            self.x1 = np.array(data[data['X'][0][0]]).astype(np.float32).transpose()
            self.x2 = np.array(data[data['X'][1][0]]).astype(np.float32).transpose()
            self.x3 = np.array(data[data['X'][2][0]]).astype(np.float32).transpose()
            self.labels = np.array(data['Y']).astype(np.int32).reshape(13000, 1) - 1
        scaler = MinMaxScaler()
        self.X1 = scaler.fit_transform(self.x1)
        self.X2 = scaler.fit_transform(self.x2)
        self.X3 = scaler.fit_transform(self.x3)
        self.probabilities = None  # 初始化概率矩阵为None

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.X1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx]), torch.from_numpy(self.X3[idx])], self.labels[idx], probability_matrix


class Cora(Dataset):
    def __init__(self, path):
        data = scio.loadmat(path + "Cora.mat")
        self.X1 = data['coracites'].astype(np.float32)
        self.X2 = data['coracontent'].astype(np.float32)
        self.X3 = data['corainbound'].astype(np.float32)
        self.X4 = data['coraoutbound'].astype(np.float32)
        self.labels = np.copy(data['y']).astype(np.int32).reshape(2708, )
        self.probabilities = None  # 初始化概率矩阵为None
        import copy
        self.X4 = np.append(self.X4, copy.deepcopy(self.X4[2704:]), axis=0)

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __len__(self):
        return self.X1.shape[0]

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx]), torch.from_numpy(self.X3[idx]), torch.from_numpy(self.X4[idx])], \
            self.labels[idx], probability_matrix


class CCV(Dataset):
    def __init__(self, path):
        self.data1 = np.load(path + 'STIP.npy').astype(np.float32)
        scaler = MinMaxScaler()
        self.data1 = scaler.fit_transform(self.data1)
        self.data2 = np.load(path + 'SIFT.npy').astype(np.float32)
        self.data3 = np.load(path + 'MFCC.npy').astype(np.float32)
        self.labels = np.load(path + 'label.npy')
        self.probabilities = None  # 初始化概率矩阵为None

        min_max_scaler = preprocessing.MinMaxScaler()
        self.X1 = min_max_scaler.fit_transform(self.data1)
        self.X2 = min_max_scaler.fit_transform(self.data2)
        self.X3 = min_max_scaler.fit_transform(self.data3)

    def __len__(self):
        return 6773

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __getitem__(self, idx):
        X1 = self.X1[idx]
        X2 = self.X2[idx]
        X3 = self.X3[idx]
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(X1), torch.from_numpy(X2), torch.from_numpy(X3)], torch.from_numpy(self.labels[idx]), probability_matrix


class MNIST_USPS(Dataset):
    def __init__(self, path):
        self.labels = scipy.io.loadmat(path + 'MNIST_USPS.mat')['Y'].astype(np.int32).reshape(5000, )
        self.X1 = scipy.io.loadmat(path + 'MNIST_USPS.mat')['X1'].astype(np.float32)
        self.X2 = scipy.io.loadmat(path + 'MNIST_USPS.mat')['X2'].astype(np.float32)
        self.probabilities = None  # 初始化概率矩阵为None

    def __len__(self):
        return 5000

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __getitem__(self, idx):

        x1 = self.X1[idx].reshape(784)
        x2 = self.X2[idx].reshape(784)
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(x1), torch.from_numpy(x2)], self.labels[idx], probability_matrix


class Cifar10(Dataset):
    def __init__(self, path):
        self.X1 = scipy.io.loadmat(path + 'cifar10.mat')['data'][0][0].astype(np.float32).T
        self.X2 = scipy.io.loadmat(path + 'cifar10.mat')['data'][1][0].astype(np.float32).T
        self.X3 = scipy.io.loadmat(path + 'cifar10.mat')['data'][2][0].astype(np.float32).T
        self.X1 = min_max_scaler.fit_transform(self.X1)
        self.X2 = min_max_scaler.fit_transform(self.X2)
        self.X3 = min_max_scaler.fit_transform(self.X3)
        self.view = 3
        self.labels = scipy.io.loadmat(path + 'cifar10.mat')['truelabel'][0][0].transpose().astype(np.int32).reshape(50000, ) - 1
        self.probabilities = None  # 初始化概率矩阵为None

    def __len__(self):
        return 50000

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.X1), torch.from_numpy(self.X2), torch.from_numpy(self.X3)], self.labels[idx], probability_matrix


class Fashion(Dataset):
    def __init__(self, path):
        self.labels = scipy.io.loadmat(path + 'Fashion.mat')['Y'].astype(np.int32).reshape(10000, )
        self.V1 = scipy.io.loadmat(path + 'Fashion.mat')['X1'].astype(np.float32).reshape(10000, 784)
        self.V2 = scipy.io.loadmat(path + 'Fashion.mat')['X2'].astype(np.float32).reshape(10000, 784)
        self.V3 = scipy.io.loadmat(path + 'Fashion.mat')['X3'].astype(np.float32).reshape(10000, 784)

        min_max_scaler = preprocessing.MinMaxScaler()
        self.X1 = min_max_scaler.fit_transform(self.V1)
        self.X2 = min_max_scaler.fit_transform(self.V2)
        self.X3 = min_max_scaler.fit_transform(self.V3)
        self.probabilities = None  # 初始化概率矩阵为None

    def __len__(self):
        return 10000

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __getitem__(self, idx):
        X1 = self.X1[idx]
        X2 = self.X2[idx]
        X3 = self.X3[idx]
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(X1), torch.from_numpy(X2), torch.from_numpy(X3)], self.labels[idx], probability_matrix


class HW(Dataset):
    def __init__(self, path):
        self.xx1 = scipy.io.loadmat(path + "/HW.mat")['X1'].astype(np.float32)
        self.xx2 = scipy.io.loadmat(path + "/HW.mat")['X2'].astype(np.float32)
        self.xx3 = scipy.io.loadmat(path + "/HW.mat")['X3'].astype(np.float32)
        self.xx4 = scipy.io.loadmat(path + "/HW.mat")['X4'].astype(np.float32)
        self.xx5 = scipy.io.loadmat(path + "/HW.mat")['X5'].astype(np.float32)
        self.xx6 = scipy.io.loadmat(path + "/HW.mat")['X6'].astype(np.float32)
        self.labels = scipy.io.loadmat(path + "/HW.mat")['Y'].astype(np.int32).reshape(2000, )
        self.probabilities = None  # 初始化概率矩阵为None

        min_max_scaler = preprocessing.MinMaxScaler()
        self.X1 = min_max_scaler.fit_transform(self.xx1).reshape(-1,216)
        self.X2 = min_max_scaler.fit_transform(self.xx2).reshape(-1,76)
        self.X3 = min_max_scaler.fit_transform(self.xx3).reshape(-1,64)
        self.X4 = min_max_scaler.fit_transform(self.xx4).reshape(-1,6)
        self.X5 = min_max_scaler.fit_transform(self.xx5).reshape(-1,240)
        self.X6 = min_max_scaler.fit_transform(self.xx6).reshape(-1,47)

    def __len__(self):
        return 2000

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __getitem__(self, idx):
        xx1 = self.X1[idx]
        xx2 = self.X2[idx]
        xx3 = self.X3[idx]
        xx4 = self.X4[idx]
        xx5 = self.X5[idx]
        xx6 = self.X6[idx]
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(xx1), torch.from_numpy(xx2), torch.from_numpy(xx3), torch.from_numpy(xx4), torch.from_numpy(xx5), torch.from_numpy(xx6)], self.labels[idx], probability_matrix


class Hdigit():
    def __init__(self, path):
        data = scipy.io.loadmat(path + 'Hdigit.mat')
        self.labels = data['truelabel'][0][0].astype(np.int32).reshape(10000, )
        self.V1 = data['data'][0][0].T.astype(np.float32)
        self.V2 = data['data'][0][1].T.astype(np.float32)
        self.probabilities = None  # 初始化概率矩阵为None
        from sklearn import preprocessing
        min_max_scaler = preprocessing.MinMaxScaler()
        self.X1 = min_max_scaler.fit_transform(self.V1)
        self.X2 = min_max_scaler.fit_transform(self.V2)
        indices = np.random.permutation(len(self.X1))
        self.X1 = self.X1[indices]
        self.X2 = self.X2[indices]
        self.labels = self.labels[indices]

    def __len__(self):
        return 10000

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)
        return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx])], self.labels[idx], probability_matrix


class Caltech(Dataset):
    def __init__(self, path, view):
        data = scipy.io.loadmat(path)
        scaler = MinMaxScaler()
        self.X1 = scaler.fit_transform(data['X1'].astype(np.float32))
        self.X2 = scaler.fit_transform(data['X2'].astype(np.float32))
        self.X3 = scaler.fit_transform(data['X5'].astype(np.float32))
        self.X4 = scaler.fit_transform(data['X4'].astype(np.float32))
        self.X5 = scaler.fit_transform(data['X3'].astype(np.float32))
        self.labels = scipy.io.loadmat(path)['Y'].transpose()
        self.probabilities = None  # 初始化概率矩阵为None
        self.view = view


    def __len__(self):
        return 1400

    def set_probabilities(self, probabilities):
        self.probabilities = probabilities

    def __getitem__(self, idx):
        if self.probabilities is not None:
            probability_matrix = self.probabilities[idx]
        else:
            # 如果概率矩阵为None，返回一个与标签相同 dtype 的全零张量
            probability_matrix = torch.zeros_like(torch.Tensor([idx]), dtype=torch.float32)

        if self.view == 2:
            return [torch.from_numpy(
                self.X1[idx]), torch.from_numpy(self.X2[idx])], torch.from_numpy(self.labels[idx]), probability_matrix
        if self.view == 3:
            return [torch.from_numpy(self.X1[idx]), torch.from_numpy(
                self.X2[idx]), torch.from_numpy(self.X3[idx])], torch.from_numpy(self.labels[idx]), probability_matrix
        if self.view == 4:
            return [torch.from_numpy(self.X1[idx]), torch.from_numpy(self.X2[idx]), torch.from_numpy(
                self.X3[idx]), torch.from_numpy(self.X4[idx])], torch.from_numpy(self.labels[idx]), probability_matrix
        if self.view == 5:
            return [torch.from_numpy(self.X1[idx]), torch.from_numpy(
                self.X2[idx]), torch.from_numpy(self.X3[idx]), torch.from_numpy(
                self.X4[idx]), torch.from_numpy(self.X5[idx])], torch.from_numpy(self.labels[idx]), probability_matrix


def load_data(dataset):
    if dataset == "BDGP":
        dataset = BDGP('./data/')
        dims = [1750, 79]
        view = 2
        data_size = 2500
        class_num = 5
    elif dataset == "MNIST_USPS":
        dataset = MNIST_USPS('./data/')
        dims = [784, 784]
        view = 2
        class_num = 10
        data_size = 5000
    elif dataset == "Hdigit":
        dataset = Hdigit('./data/')
        dims = [784, 256]
        view = 2
        data_size = 10000
        class_num = 10
    elif dataset == "CCV":
        dataset = CCV('./data/')
        dims = [5000, 5000, 4000]
        view = 3
        data_size = 6773
        class_num = 20
    elif dataset == "Fashion":
        dataset = Fashion('./data/')
        dims = [784, 784, 784]
        view = 3
        data_size = 10000
        class_num = 10
    elif dataset == "Cifar10":
        dataset = Cifar10('./data/')
        dims = [512, 2048, 1024]
        view = 3
        class_num = 10
        data_size = 50000
    elif dataset == "HW":
        dataset = HW('./data/')
        dims = [216, 76, 64, 6, 240, 47]
        view = 6
        data_size = 2000
        class_num = 10
    elif dataset == "Caltech-2V":
        dataset = Caltech('data/Caltech-5V.mat', view=2)
        dims = [40, 254]
        view = 2
        data_size = 1400
        class_num = 7
    elif dataset == "Caltech-3V":
        dataset = Caltech('data/Caltech-5V.mat', view=3)
        dims = [40, 254, 928]
        view = 3
        data_size = 1400
        class_num = 7
    elif dataset == "Caltech-4V":
        dataset = Caltech('data/Caltech-5V.mat', view=4)
        dims = [40, 254, 928, 512]
        view = 4
        data_size = 1400
        class_num = 7
    elif dataset == "Caltech-5V":
        dataset = Caltech('data/Caltech-5V.mat', view=5)
        dims = [40, 254, 928, 512, 1984]
        view = 5
        data_size = 1400
        class_num = 7
    elif dataset == "STL10":
        dataset = STL10('data/STL10.mat')
        dims = [1024, 512, 2048]
        view = 3
        data_size = 13000
        class_num = 10
    elif dataset == "BBCSport":
        dataset = BBCSport('./data/')
        dims = [3183, 3203]
        view = 2
        data_size = 544
        class_num = 5
    elif dataset == "REU":
        dataset = REU('./data/')
        dims = [2000, 2000, 2000, 2000, 2000]
        view = 5
        data_size = 1200
        class_num = 6
    elif dataset == "COIL20":  # G
        dataset = COIL20('./data/')
        dims = [1024, 3304, 6750]
        view = 3
        data_size = 1440
        class_num = 20
    elif dataset == "Cora":
        dataset = Cora('./data/')
        dims = [2708, 1433, 2706, 2708]
        view = 4
        data_size = 2708
        class_num = 7
    elif dataset == "synthetic3d":
        dataset = synthetic3d('./data/')
        dims = [3, 3, 3]
        view = 3
        data_size = 600
        class_num = 3
    elif dataset == "scene-15":
        dataset = scene('./data/')
        dims = [20, 59, 40]
        view = 3
        data_size = 4485
        class_num = 15
    elif dataset == "Caltech101":
        dataset = Caltech101('./data/')
        dims = [48, 40, 254, 1984, 512]
        view = 5
        data_size = 9144
        class_num = 102
    elif dataset == "YoutubeFace_sel_fea":
        dataset = YoutubeFace_sel_fea('./data/')
        dims = [64, 512, 64, 647, 838]
        view = 5
        data_size = 101499
        class_num = 31
    elif dataset == "LandUse_21":
        dataset = LandUse_21('./data/')
        dims = [20, 59, 40]
        view = 3
        data_size = 2100
        class_num = 21
    elif dataset == "NUSWIDE":
        dataset = NUSWIDE('./data/')
        dims = [65, 226, 145, 74, 129]
        view = 5
        data_size = 5000
        class_num = 5
    elif dataset == "LLMs":
        dataset = LLMs('./data/')
        dims = [32*32*3, 32*32*3, 32*32*3]
        view = 3
        data_size = 1000
        class_num = 10
    else:
        raise NotImplementedError
    return dataset, dims, view, data_size, class_num

