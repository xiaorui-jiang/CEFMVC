# -*- coding: gbk -*-
import torch
from network import Network_FL, FeatureContrastiveModule
from metric import valid, update_p
from torch.utils.data import Dataset
import numpy as np
import argparse
import random
from loss import Loss
import copy
import os
from dataloader import load_data, DatasetSplit
from torch.utils.data import Dataset, DataLoader
from scipy.optimize import linear_sum_assignment

# os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# MNIST-USPS
# BDGP
# CCV
# Fashion
# Hdigit
# Caltech-2V
# Caltech-3V
# Caltech-4V
# Caltech-5V

Dataname = 'BDGP'
parser = argparse.ArgumentParser(description='train')
parser.add_argument('--dataset', default=Dataname)
parser.add_argument('--batch_size', default=256, type=int)
parser.add_argument("--temperature_f", default=0.5)
parser.add_argument("--learning_rate", default=0.0003)
parser.add_argument("--mse_epochs", default=500)
parser.add_argument("--feature_dim", default=512)
parser.add_argument("--high_feature_dim", default=128)

args = parser.parse_args()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.cuda.set_device(0)


if args.dataset == "REU":  # (args.con_epochs;  SEED ; lambda)  =  (50. 15,  0.6) (500. 12,  0) (500. 11,  0)
    args.con_epochs = 50  # (con_epochs; threshold, seed)  (500,0,11)  (500,0,12)
    args.threshold = 0
    seed = 12
if args.dataset == "synthetic3d":  # (con_epochs; threshold, seed)  (90,2,10) (90,2,15) (90,2,20) (90,2,25) (90,2,30)
    args.con_epochs = 90
    args.threshold = 0
    seed = 10
if args.dataset == "NUSWIDE":  # (con_epochs; threshold, seed)  (20, 0.75, 2024) (20, 0.8, 10)  (25, 0.75, 15) (20, 0.8, 16) (20, 0.8, 17)  (20, 0.8, 18)
    args.con_epochs =  500
    args.threshold = 0.
    seed = 1
if args.dataset == "MNIST_USPS":  # lr=0.001 miss=0.1;  con=25; loss=2; seed=1��5��10��20; ***  miss=0.5;  con=30/30/25; loss=1; seed=10��5��1;  ***  miss=0.7;  con=50/30/30; loss=2; seed=20/10/5;
    args.con_epochs = 20  # (miss_rate; con_epochs; threshold, seed) = (0.1; 25; 1, 1) (0.1; 25; 1, 5) (0.1; 25; 1, 10)  (0.1; 25; 1, 15) (0.1; 25; 1, 20)
    args.threshold = 0  # (0.3; 30; 0.6, 1)  (0.3; 30; 0.6, 5)  (0.3; 25; 0.6, 10)  (0.3; 30; 0.6, 20) (0.5; 35; 0.6, 1) (0.5; 35; 0.6, 5) (0.5; 33; 0.6, 10) (0.5; 33; 0.6, 15)  (0.5; 35; 0.6, 15)
    seed = 15
if args.dataset == "BDGP":  # lr=0.001 miss=0.1;  con=25; loss=2; seed=1��5��10��20; ***  miss=0.5;  con=30/30/25; loss=1; seed=10��5��1;  ***  miss=0.7;  con=50/30/30; loss=2; seed=20/10/5;
    args.con_epochs = 15  # (miss_rate; con_epochs; threshold, seed) = (0.1; 25; 1, 1) (0.1; 25; 1, 5) (0.1; 25; 1, 10)  (0.1; 25; 1, 15) (0.1; 25; 1, 20)
    args.threshold = 0.  # (0.3; 30; 0.6, 1)  (0.3; 30; 0.6, 5)  (0.3; 25; 0.6, 10)  (0.3; 30; 0.6, 20) (0.5; 35; 0.6, 1) (0.5; 35; 0.6, 5) (0.5; 33; 0.6, 10) (0.5; 33; 0.6, 15)  (0.5; 35; 0.6, 15)
    seed = 2025
if args.dataset == "Hdigit":  # lr=0.001 miss=0.1;  con=25; loss=2; seed=1��5��10��20; ***  miss=0.5;  con=30/30/25; loss=1; seed=10��5��1;  ***  miss=0.7;  con=50/30/30; loss=2; seed=20/10/5;
    args.con_epochs = 20  # (miss_rate; con_epochs; threshold, seed) = (0.1; 25; 1, 1) (0.1; 25; 1, 5) (0.1; 25; 1, 10)  (0.1; 25; 1, 15) (0.1; 25; 1, 20)
    args.threshold = 0.29  # (0.3; 30; 0.6, 1)  (0.3; 30; 0.6, 5)  (0.3; 25; 0.6, 10)  (0.3; 30; 0.6, 20) (0.5; 35; 0.6, 1) (0.5; 35; 0.6, 5) (0.5; 33; 0.6, 10) (0.5; 33; 0.6, 15)  (0.5; 35; 0.6, 15)
    seed = 15
if args.dataset == "Cifar10":
    args.con_epochs = 15
    args.threshold = 0
    seed = 15
if args.dataset == "BBCSport":
    args.con_epochs = 20
    args.threshold = 2
    seed = 15
if args.dataset == "CCV":  # lr=0.001 miss=0.1;  con=25; loss=2; seed=1��5��10��20; ***  miss=0.5;  con=30/30/25; loss=1; seed=10��5��1;  ***  miss=0.7;  con=50/30/30; loss=2; seed=20/10/5;
    args.con_epochs =20  # (miss_rate; con_epochs; threshold, seed) = (0.1; 25; 1, 1) (0.1; 25; 1, 5) (0.1; 25; 1, 10)  (0.1; 25; 1, 15) (0.1; 25; 1, 20)
    args.threshold = 0  # (0.3; 30; 0.6, 1)  (0.3; 30; 0.6, 5)  (0.3; 25; 0.6, 10)  (0.3; 30; 0.6, 20) (0.5; 35; 0.6, 1) (0.5; 35; 0.6, 5) (0.5; 33; 0.6, 10) (0.5; 33; 0.6, 15)  (0.5; 35; 0.6, 15)
    seed = 15
if args.dataset == "STL10":  # lr=0.001 miss=0.1;  con=25; loss=2; seed=1��5��10��20; ***  miss=0.5;  con=30/30/25; loss=1; seed=10��5��1;  ***  miss=0.7;  con=50/30/30; loss=2; seed=20/10/5;
    args.con_epochs = 5  # (miss_rate; con_epochs; threshold, seed) = (0.1; 25; 1, 1) (0.1; 25; 1, 5) (0.1; 25; 1, 10)  (0.1; 25; 1, 15) (0.1; 25; 1, 20)
    args.threshold = 2 # (0.3; 30; 0.6, 1)  (0.3; 30; 0.6, 5)  (0.3; 25; 0.6, 10)  (0.3; 30; 0.6, 20) (0.5; 35; 0.6, 1) (0.5; 35; 0.6, 5) (0.5; 33; 0.6, 10) (0.5; 33; 0.6, 15)  (0.5; 35; 0.6, 15)
    seed = 2025
if args.dataset == "Fashion":
    args.con_epochs = 20  # (miss_rate; con_epochs; threshold, seed) = (0.1; 25; 1, 1) (0.1; 25; 1, 5) (0.1; 25; 1, 10)  (0.1; 25; 1, 15) (0.1; 25; 1, 20)
    args.threshold = 0  # (0.3; 30; 0.6, 1)  (0.3; 30; 0.6, 5)  (0.3; 25; 0.6, 10)  (0.3; 30; 0.6, 20) (0.5; 35; 0.6, 1) (0.5; 35; 0.6, 5) (0.5; 33; 0.6, 10) (0.5; 33; 0.6, 15)  (0.5; 35; 0.6, 15)
    seed = 15

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


dataset, dims, view, data_size, class_num = load_data(args.dataset)


def pretrain(model, loader):
    model.train()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    for epo in range(args.mse_epochs):
        tot_loss = 0.
        criterion = torch.nn.MSELoss()
        for batch_idx, (xs, _, _) in enumerate(loader):
            xs = xs.to(device)
            optimizer.zero_grad()
            _, _, xrs, _ = model(xs)
            loss_list = []
            loss_list.append(criterion(xs, xrs))
            loss = sum(loss_list)
            loss.backward()
            optimizer.step()
            tot_loss += loss.item()
        print('Epoch {}'.format(epo), 'Loss:{:.6f}'.format(tot_loss / len(loader)))


def new_train(model, light_models_except_now_view, loader, local_features):
    model.train()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    optimizer_list = []
    for lm in range(len(light_models_except_now_view)):
        light_models_except_now_view[lm].train()
        optimizer_list.append(torch.optim.Adam(light_models_except_now_view[lm].parameters(), lr=args.learning_rate))
    MSE = torch.nn.MSELoss()
    for epo in range(args.con_epochs):
        tot_loss = 0.
        con_fea = []
        ys_list = []
        xs, ys, p = next(iter(loader))
        indices = list(range(data_size))
        random.shuffle(indices)
        for da in range(0, data_size, args.batch_size):
            batch_indices = indices[da:da + args.batch_size]
            xs = xs.to(device)
            batch_xs = xs[batch_indices]
            batch_ys = ys[batch_indices]
            batch_p = p[batch_indices]
            optimizer.zero_grad()
            for v in range(len(light_models_except_now_view)):
                optimizer_list[v].zero_grad()
            hs, _, xrs, _ = model(batch_xs)
            loss_list = []
            for v in range(len(light_models_except_now_view)):
                pair_hs = light_models_except_now_view[v](local_features[v][batch_indices])
                loss_list.append(criterion.forward_new(hs, pair_hs, np.concatenate([batch_p, batch_p]), args.threshold))
            loss_list.append(MSE(batch_xs, xrs))
            con_fea.append(hs)
            ys_list.append(batch_ys)
            loss = sum(loss_list)
            loss.backward()
            optimizer.step()
            for v in range(len(light_models_except_now_view)):
                optimizer_list[v].step()
            tot_loss += loss.item()

        con_fea = torch.cat(con_fea, dim=0)
        tmp_local_features = []
        for v in range(len(light_models_except_now_view)):
            tmp_local_features.append(light_models_except_now_view[v](local_features[v][indices]))
        tmp_local_features.append(con_fea)
        update_p(tmp_local_features, device, loader, class_num, torch.cat(ys_list, dim=0))
        print('Epoch {}'.format(epo), 'Loss:{:.6f}'.format(tot_loss / len(loader)))


def match(y_true, y_pred):
    y_true = y_true.astype(np.int64)
    y_pred = y_pred.astype(np.int64)
    assert y_pred.size == y_true.size
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    row_ind, col_ind = linear_sum_assignment(w.max() - w)
    new_y = np.zeros(y_true.shape[0])
    for i in range(y_pred.size):
        for j in row_ind:
            if y_true[i] == col_ind[j]:
                new_y[i] = row_ind[j]
    new_y = torch.from_numpy(new_y).long().to(device)
    new_y = new_y.view(new_y.size()[0])
    return new_y


def freeze_models(models):
    for vi in range(1):
        for param in models[vi].encoder.parameters():
            param.requires_grad = False
        for param in models[vi].decoder.parameters():
            param.requires_grad = False



from sklearn.cluster import KMeans
def valid_client1(valid_model_list, device, valid_dataset_list):
    local_zs, local_ys, local_hs = [], [], []
    for an in range(1):
        zs_list, ys_list, hs_list = [], [], []
        for batch_idx, (xs, ys, _) in enumerate(valid_dataset_list[an]):
            xs = xs.to(device)
            hs, q, xr, zs = valid_model_list[an](xs)
            ys_list.append(ys)
            hs_list.append(hs)
            zs_list.append(zs)
        local_ys.append(torch.cat(ys_list, dim=0))
        local_hs.append(torch.cat(hs_list, dim=0))
        local_zs.append(torch.cat(zs_list, dim=0))
    return local_zs[0]


accs = []
nmis = []
purs = []
if not os.path.exists('./models'):
    os.makedirs('./models')


import pickle
import socket
HOST = '222.195.90.252'
PORT = 5000
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((HOST, PORT))


client_identity = "view 2"  # ���緢������ "view 1"
client_socket.sendall(client_identity.encode('utf-8'))

T = 1
for ii in range(1):

    print("ROUND:{}".format(ii + 1))
    setup_seed(seed + ii)

    criterion = Loss(args.batch_size, class_num, args.temperature_f, device).to(device)

    data_loader_list = []
    data_loader_list_all = []

    data_loader = DataLoader(DatasetSplit(copy.deepcopy(getattr(dataset, 'X' + str(2))), copy.deepcopy(dataset.labels), dims[1], copy.deepcopy(dataset.probabilities)), batch_size=args.batch_size, shuffle=True)
    data_loader_list.append(copy.deepcopy(data_loader))
    data_loader_all = DataLoader(DatasetSplit(copy.deepcopy(getattr(dataset, 'X' + str(2))), copy.deepcopy(dataset.labels), dims[1], copy.deepcopy(dataset.probabilities)), batch_size=len(dataset), shuffle=False)
    data_loader_list_all.append(copy.deepcopy(data_loader_all))

    models = []
    for vi in range(1,2):
        models.append(copy.deepcopy(Network_FL(args.batch_size, dims[vi], args.feature_dim, args.feature_dim, class_num, device).to(device)))

    for vi in range(1):
        pretrain(models[vi], data_loader_list[vi])

    freeze_models(models)

    local_zs = valid_client1(models, device, data_loader_list_all)

    data = pickle.dumps(local_zs)
    data_length = len(data)
    client_socket.sendall(data_length.to_bytes(4, byteorder='big'))  # ���ͳ�����Ϣ
    client_socket.sendall(data)  # ����ʵ������

    # ���շ���������Ӧ
    response = client_socket.recv(1024)
    print("Server response:", response.decode('utf-8'))

    # �ȴ����ղ���ӡ�㲥��Ϣ
    print("Waiting for server broadcast...")

    # �洢���յ��Ĺ㲥��Ϣ
    received_messages = []

    # ���ý�����Ϣ�����������磬���� 3 ����Ϣ��Ͽ����ӣ�
    max_messages = view - 1


    while len(received_messages) < max_messages:
        data_length = int.from_bytes(client_socket.recv(4), byteorder='big')
        print(f"Expected data length: {data_length} bytes")
        data = b''
        while len(data) < data_length:
            packet = client_socket.recv(1024)
            if not packet:
                break
            data += packet
        decoded_message = pickle.loads(data)
        print(f"Broadcast from server: {decoded_message}")
        print(decoded_message.shape)
        received_messages.append(decoded_message)  # ����Ϣ�洢����

    local_features_all_client = [local_zs] + received_messages

    # # # �ر�����
    # client_socket.close()

    light_models = []
    for vi in range(view):
        feature_contrastive_model = FeatureContrastiveModule(feature_dim=args.feature_dim, high_feature_dim=args.feature_dim, device=device).to(device)
        light_models.append(feature_contrastive_model)


    local_features_except_now_view = [tsor.detach().clone().to(device) for i, tsor in enumerate(local_features_all_client) if i != 0]
    light_models_except_now_view =  copy.deepcopy(light_models[0:1])
    new_train(models[0], light_models_except_now_view, data_loader_list_all[0], local_features_except_now_view)

    data = pickle.dumps(models[0])
    data_length = len(data)
    client_socket.sendall(data_length.to_bytes(4, byteorder='big'))  # ���ͳ�����Ϣ
    client_socket.sendall(data)  # ����ʵ������


