# -*- coding: gbk -*-
import torch
from network import Network_FL, FeatureContrastiveModule
from metric import valid, update_p
import numpy as np
import argparse
import random
from loss import Loss
import copy
import os
from dataloader import load_data, DatasetSplit
from torch.utils.data import Dataset, DataLoader
from scipy.optimize import linear_sum_assignment

# os.environ["CUDA_VISIBLE_DEVICES"] = "0"

Dataname = 'LLMs'
parser = argparse.ArgumentParser(description='train')
parser.add_argument('--dataset', default=Dataname)
parser.add_argument('--batch_size', default=256, type=int)
parser.add_argument("--temperature_f", default=0.5)
parser.add_argument("--learning_rate", default=0.0003)
parser.add_argument("--mse_epochs", default=500)
parser.add_argument("--feature_dim", default=512)
parser.add_argument("--high_feature_dim", default=128)

args = parser.parse_args()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.cuda.set_device(7)

if args.dataset == "REU":
    args.con_epochs = 80
    args.threshold = 0.5
    seed = 1
if args.dataset == "synthetic3d":  # 100 + 0.0001 + 0
    args.con_epochs = 100
    args.learning_rate = 0.0001
    args.threshold = 0
    seed = 1
if args.dataset == "NUSWIDE":
    args.con_epochs = 100
    args.threshold = 2.75
    seed = 10
if args.dataset == "MNIST_USPS":
    args.con_epochs = 20
    args.threshold = 0
    seed = 15
if args.dataset == "BDGP":  # 20 + 0
    args.con_epochs = 20
    args.threshold = 0.
    seed = 1
if args.dataset == "Hdigit":
    args.con_epochs = 20
    args.threshold = 0
    seed = 10
if args.dataset == "Cifar10":
    args.con_epochs = 15
    args.threshold = 20
    seed = 15
if args.dataset == "BBCSport":  # 2 + 0
    args.con_epochs = 1
    args.threshold = 0.
    seed = 6
if args.dataset == "STL10":  # 5 + 0
    args.con_epochs = 5
    args.threshold = 0
    seed = 10
if args.dataset == "Fashion":
    args.con_epochs = 30
    args.threshold = 20
    seed = 1
if args.dataset == "Caltech-2V":
    args.con_epochs = 100  # 100 +  0
    args.threshold = 0.6
    seed = 40
if args.dataset == "Cora":
    args.con_epochs = 20  # 20 + 0.6
    args.threshold = 0.6
    seed = 6
if args.dataset == "LLMs":  # 50 + 0.8
    args.con_epochs = 50
    args.threshold = .8
    seed = 4


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


dataset, dims, view, data_size, class_num = load_data(args.dataset)


def pretrain(model, loader):
    model.train()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    for epo in range(args.mse_epochs):
        tot_loss = 0.
        criterion = torch.nn.MSELoss()
        for batch_idx, (xs, _, _) in enumerate(loader):
            xs = xs.to(device)
            optimizer.zero_grad()
            _, _, xrs, _ = model(xs)
            loss_list = []
            loss_list.append(criterion(xs, xrs))
            loss = sum(loss_list)
            loss.backward()
            optimizer.step()
            tot_loss += loss.item()
        #print('Epoch {}'.format(epo), 'Loss:{:.6f}'.format(tot_loss / len(loader)))


def new_train(model, light_models_except_now_view, loader, local_features):
    model.train()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    optimizer_list = []
    for lm in range(len(light_models_except_now_view)):
        light_models_except_now_view[lm].train()
        optimizer_list.append(torch.optim.Adam(light_models_except_now_view[lm].parameters(), lr=args.learning_rate))
    MSE = torch.nn.MSELoss()
    for epo in range(args.con_epochs):
        tot_loss = 0.
        con_fea = []
        ys_list = []
        xs, ys, p = next(iter(loader))
        indices = list(range(data_size))
        random.shuffle(indices)
        for da in range(0, data_size, args.batch_size):
            batch_indices = indices[da:da + args.batch_size]
            xs = xs.to(device)
            batch_xs = xs[batch_indices]
            batch_ys = ys[batch_indices]
            batch_p = p[batch_indices]
            optimizer.zero_grad()
            for v in range(len(light_models_except_now_view)):
                optimizer_list[v].zero_grad()
            hs, _, xrs, _ = model(batch_xs)
            loss_list = []
            for v in range(len(light_models_except_now_view)):
                pair_hs = light_models_except_now_view[v](local_features[v][batch_indices])
                loss_list.append(criterion.forward_new(hs, pair_hs, np.concatenate([batch_p, batch_p]), args.threshold))
            loss_list.append(MSE(batch_xs, xrs))
            con_fea.append(hs)
            ys_list.append(batch_ys)
            loss = sum(loss_list)
            loss.backward()
            optimizer.step()
            for v in range(len(light_models_except_now_view)):
                optimizer_list[v].step()
            tot_loss += loss.item()
        con_fea = torch.cat(con_fea, dim=0)
        tmp_local_features = []
        for v in range(len(light_models_except_now_view)):
            tmp_local_features.append(light_models_except_now_view[v](local_features[v][indices]))
        tmp_local_features.append(con_fea)
        update_p(tmp_local_features, device, loader, class_num, torch.cat(ys_list, dim=0))
        #print('Epoch {}'.format(epo), 'Loss:{:.6f}'.format(tot_loss / len(loader)))


def match(y_true, y_pred):
    y_true = y_true.astype(np.int64)
    y_pred = y_pred.astype(np.int64)
    assert y_pred.size == y_true.size
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    row_ind, col_ind = linear_sum_assignment(w.max() - w)
    new_y = np.zeros(y_true.shape[0])
    for i in range(y_pred.size):
        for j in row_ind:
            if y_true[i] == col_ind[j]:
                new_y[i] = row_ind[j]
    new_y = torch.from_numpy(new_y).long().to(device)
    new_y = new_y.view(new_y.size()[0])
    return new_y


def freeze_models(models):
    for vi in range(view):
        for param in models[vi].encoder.parameters():
            param.requires_grad = False
        for param in models[vi].decoder.parameters():
            param.requires_grad = False


accs = []
nmis = []
purs = []
if not os.path.exists('./models'):
    os.makedirs('./models')

T = 1

args.threshold = 0

for iii in range(10):



    print("ROUND:{}".format(iii + 1))

    print('args.threshold', args.threshold)

    setup_seed(seed + iii)

    criterion = Loss(args.batch_size, class_num, args.temperature_f, device).to(device)

    data_loader_list = []
    data_loader_list_all = []
    for i in range(1, view + 1):
        data_loader = DataLoader(DatasetSplit(copy.deepcopy(getattr(dataset, 'X' + str(i))), copy.deepcopy(dataset.labels), dims[i - 1], copy.deepcopy(dataset.probabilities)), batch_size=args.batch_size, shuffle=True)
        data_loader_list.append(copy.deepcopy(data_loader))
        data_loader_all = DataLoader(DatasetSplit(copy.deepcopy(getattr(dataset, 'X' + str(i))), copy.deepcopy(dataset.labels), dims[i - 1], copy.deepcopy(dataset.probabilities)), batch_size=len(dataset), shuffle=False)
        data_loader_list_all.append(copy.deepcopy(data_loader_all))

    models = []
    for vi in range(view):
        models.append(copy.deepcopy(Network_FL(args.batch_size, dims[vi], args.feature_dim, args.feature_dim, class_num, device).to(device)))

    for vi in range(view):
        pretrain(models[vi], data_loader_list[vi])

    freeze_models(models)

    local_features_all_client = valid(models, device, data_loader_list_all, view, class_num)

    light_models = []
    for vi in range(view):
        feature_contrastive_model = FeatureContrastiveModule(feature_dim=args.feature_dim, high_feature_dim=args.feature_dim, device=device).to(device)
        light_models.append(feature_contrastive_model)

    for vi in range(view):
        local_features_except_now_view = [tsor.detach().clone().to(device) for i, tsor in enumerate(local_features_all_client) if i != vi]
        light_models_except_now_view = copy.deepcopy(light_models[:vi]) + copy.deepcopy(light_models[vi + 1:])
        new_train(models[vi], light_models_except_now_view, data_loader_list_all[vi], local_features_except_now_view)

    valid(models, device, data_loader_list_all, view, class_num)
    args.threshold += 0.2