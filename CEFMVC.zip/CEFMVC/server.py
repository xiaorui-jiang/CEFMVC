import socket
import pickle
from metric import valid
import torch
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.cuda.set_device(0)
import copy
from dataloader import load_data, DatasetSplit
from torch.utils.data import Dataset, DataLoader

Dataname = 'BDGP'
dataset, dims, view, data_size, class_num = load_data(Dataname)

# 配置常量
BUFFER_SIZE = 4096
PORT = 5000
MAX_CONNECTIONS = 5
TIMEOUT = 600
EXPECTED_CLIENTS = ["view 1", "view 2"]

data_loader_final = []
for i in range(1, view + 1):
    data_loader_all = DataLoader(DatasetSplit(copy.deepcopy(getattr(dataset, 'X' + str(i))), copy.deepcopy(dataset.labels), dims[i - 1], copy.deepcopy(dataset.probabilities)), batch_size=len(dataset), shuffle=False)
    data_loader_final.append(copy.deepcopy(data_loader_all))


# 创建 Socket 并绑定端口
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('222.195.90.252', PORT))
server_socket.listen(MAX_CONNECTIONS)

print(f"Server is listening on port {PORT}...")

clients_data = {}  # 用字典存储客户端身份和它们发送的数据
clients_connected = []  # 用列表记录已连接的客户端身份
models = []

# 广播函数
def broadcast(message, sender_socket):
    for client_socket, identity in clients_data.items():
        if client_socket != sender_socket:  # 不广播给发送消息的客户端
            try:
                client_socket.sendall(len(message).to_bytes(4, byteorder='big'))  # 发送长度信息
                client_socket.sendall(message)
            except Exception as e:
                print(f"Error broadcasting to {identity}: {e}")


while True:
    try:
        # 设置超时时间，防止长时间无响应
        client_socket, addr = server_socket.accept()
        client_socket.settimeout(TIMEOUT)  # 设置连接超时时间
        print(f"Connected by {addr}")

        # 接收身份信息
        identity = client_socket.recv(1024).decode('utf-8').strip()
        print(f"Received client identity: {identity}")

        # 验证客户端身份
        if identity not in EXPECTED_CLIENTS:
            print(f"Unknown client {identity}")
            client_socket.sendall(b"Unauthorized client!")
            client_socket.close()
            continue  # 身份不合法，跳过当前循环

        # 存储已连接客户端
        if identity not in clients_connected:
            clients_connected.append(identity)

        # 接收数据长度
        data_length = int.from_bytes(client_socket.recv(4), byteorder='big')
        print(f"Expected data length: {data_length} bytes")

        # 接收完整的数据
        data = b''
        while len(data) < data_length:
            packet = client_socket.recv(BUFFER_SIZE)
            if not packet:
                break
            data += packet

        # 确保接收的数据完整
        if len(data) == data_length:
            try:
                local_zs = pickle.loads(data)  # 解码数据
                print(f"Received data from {identity}:")


                # 将数据存储在字典中
                clients_data[client_socket] = identity, pickle.dumps(local_zs)

                client_socket.sendall(b"Matrix received successfully!")

                # 如果所有预期客户端的数据都已经接收完毕，进行广播
                if set(EXPECTED_CLIENTS) == set(clients_connected):
                    print("All clients have sent their data. Broadcasting...")
                    for client_socket, (_, data) in clients_data.items():
                        broadcast(data, client_socket)
                    print("Broadcasting...Done!")

                    # 继续接收客户端的模型数据
                    for client_socket, identity in clients_data.items():

                        print(f"Waiting models")

                        # 读取模型数据
                        model_data_length = int.from_bytes(client_socket.recv(4), byteorder='big')
                        print(model_data_length)

                        model_data = b''
                        while len(model_data) < model_data_length:
                            packet = client_socket.recv(BUFFER_SIZE)
                            if not packet:
                                break
                            model_data += packet


                        if len(model_data) == model_data_length:
                            try:
                                # 假设模型是一个pickle序列化的对象
                                model = pickle.loads(model_data)
                                models.append((model))
                                print('Received!')

                                # 这里可以进行处理、保存或其他操作
                                if len(models) == len(clients_connected):
                                    print("All clients have sent their model. valid...")
                                    valid(models, device, data_loader_final, view, class_num)
                                    exit()

                            except Exception as e:
                                valid(models[::-1], device, data_loader_final, view, class_num)
                                print(f"Error while receiving model: {e}")

                        else:
                            print(f"Error: Incomplete model data from {identity}")


            except Exception as e:
                print(f"Error while decoding data: {e}")
                client_socket.sendall(b"Failed to decode data!")
        else:
            print("Data was incomplete!")
            client_socket.sendall(b"Failed to receive complete data!")




        # 关闭当前客户端连接
        # client_socket.close()

    except socket.timeout:
        print(f"Connection timed out after {TIMEOUT} seconds")
    except Exception as e:
        print(f"Error occurred: {e}")
